ERRACT.LS      Robot Name ROBOT 21-AUG-26 18:05:14  

254" 21-AUG-26 17:50:12 " SRVO-402 DCS Cart. pos. limit(No.1,G1,M0) 11      " " SERVO                         00110110" 
