26/08/21 11:58:50

Version:  V10.10P/28/None
Build ID: V10.10307     1/22/2026

1A05B-2500-H552
1A05B-2500-H521
1A05B-2500-R796
1A05B-2500-R651
1A05B-2500-R641
1A05B-2500-FVRC
1A05B-2500-H720
Z

 ***At the beginning of Auto Update.***

Img.Backup Yes     * must have one ' ' then 'yes' or 'no'
! Next what devices should be backed up:
! Each line needs the word "BackupDevice", then space then 
! the device name with ":"
BackupDevice FR:
BackupDevice FRA:
!BackupDevice RD:
!BackupDevice FR1:
! Next is whether saving the backup (all and image) after 
! auto update or not. Select 'YES' or 'NO' after 
! "AfterBackup" and one space. YES: save, NO: not save.
! When MC: does not have enough capacity, backup is not
! saved even if "AfterBackup YES".
AfterBackup NO
!
! Restore I/O status,  must have one ' ' then 'yes' or 'no'
SetUpIOstat Yes
!
! Controls restore point creation before auto update
! must have one ' ' then 'yes' or 'no'
RestorePoint Yes

 ***At Controlled Start.***

F Number: F00000    
VERSION : HandlingTool         
$VERSION: V10.10307     1/22/2026
DATE:     21-AUG-26 12:02 

MEMORY USAGE::

MEMORY DETAIL (MAIN):
Pools        TOTAL     AVAILABLE      LARGEST
TPP             .9MB        .9MB        .9MB
PERM           3.0MB       1.3MB       1.3MB
SYSTEM          .0MB       0.0MB       0.0MB
SHADOW         6.5MB       5.6MB        .0MB
PAGE         207.7MB     128.7MB     128.7MB
TEMP          63.9MB      42.1MB      41.5MB
FR           252.0MB     196.3MB

HARDWARE
FROM     256MB
DRAM      27MB
NVRAM       3MB

MEMORY DETAIL (MAIN - TASKS):
TASK        TOTAL     AVAILABLE     LARGEST   REALLOC
   1      282.8KB       124.3KB      62.2KB      3
   2      126.8KB        60.2KB      47.4KB      1
   3       62.8KB        10.9KB      10.9KB      0
   4       62.8KB         8.8KB       8.8KB      0
  33       62.8KB        61.4KB      61.4KB      0
  34       62.8KB        30.4KB      30.4KB      0
  36     1518.8KB      1382.8KB    1382.3KB      0
  37       62.8KB        61.5KB      61.5KB      0
  38     1998.8KB       983.7KB     983.4KB      0
  39     3366.5KB      3280.1KB     232.1KB     14
  40       62.8KB        61.6KB      61.6KB      0
  41      126.8KB        77.0KB      48.6KB      1
  42      254.8KB       186.7KB     186.6KB      0
  47       62.8KB        61.5KB      61.5KB      0
  51       62.8KB        60.8KB      60.8KB      0
  52     2574.3KB       854.2KB      73.8KB     24
  71       62.8KB        61.4KB      59.0KB      0
  72     3998.8KB      3995.2KB    3991.7KB      0
  73       62.8KB        61.9KB      61.9KB      0
  75       62.8KB        61.2KB      61.2KB      0
  76      190.8KB        54.5KB      53.6KB      1
  77       62.8KB        61.2KB      61.2KB      0
  78      254.8KB       252.5KB     248.0KB      0
  99       62.8KB        61.8KB      61.8KB      0
 101       62.8KB        56.5KB      56.5KB      0
 102       94.8KB        93.6KB      93.6KB      0
 103       94.8KB        93.6KB      93.6KB      0
 104       94.8KB        93.6KB      93.6KB      0
 105       94.8KB        93.6KB      93.6KB      0
 106       94.8KB        93.6KB      93.6KB      0
 107       94.8KB        93.6KB      93.6KB      0
 108      298.8KB        33.7KB      24.8KB      3
 109      958.8KB       584.9KB     579.8KB      0
 114       62.8KB        61.0KB      61.0KB      0
 150       62.8KB        51.4KB      51.4KB      0
 153       62.8KB        61.0KB      61.0KB      0
 159     1470.7KB        72.6KB      60.3KB      7
 166       62.8KB        28.9KB      28.9KB      0
 170     1534.3KB       475.6KB      54.1KB     23
 171       62.8KB        56.7KB      56.7KB      0
 174       62.8KB        61.0KB      61.0KB      0
 177       62.8KB        44.8KB      44.8KB      0
 182       62.8KB        35.4KB      35.4KB      0
 186       62.8KB        50.7KB      50.7KB      0
 187      190.8KB        80.9KB      30.9KB      2
 188       62.8KB        62.8KB      62.8KB      0
 189       62.8KB        62.8KB      62.8KB      0
 190       62.8KB        62.8KB      62.8KB      0
 191       62.8KB        62.8KB      62.8KB      0
 192       62.8KB        61.9KB      61.9KB      0
 193       62.8KB        62.8KB      62.8KB      0
 199       62.8KB        62.8KB      62.8KB      0
 209       62.8KB        61.8KB      61.8KB      0
 214       62.8KB        61.6KB      61.6KB      0
 221       62.8KB        50.5KB      50.5KB      0
 231       62.8KB        27.8KB      27.8KB      0
 232       62.8KB        61.5KB      61.5KB      0
 239       62.8KB        60.5KB      60.5KB      0
 240       62.8KB        49.4KB      49.4KB      0
 256       62.8KB        62.7KB      62.7KB      0
 257       62.8KB        62.8KB      62.8KB      0
 258       62.8KB        62.8KB      62.8KB      0
 259       62.8KB        62.8KB      62.8KB      0
 260       62.8KB        62.8KB      62.8KB      0
 261       62.8KB        62.8KB      62.8KB      0
 262       62.8KB        62.8KB      62.8KB      0
 263       62.8KB        62.8KB      62.8KB      0
 264       62.8KB        62.8KB      62.8KB      0
 265       62.8KB        62.8KB      62.8KB      0
 297      142.8KB        64.4KB      59.8KB      1
 301       62.8KB        61.9KB      61.9KB      0
 302      138.8KB         9.0KB       4.5KB      1
 317       62.8KB        61.9KB      61.9KB      0
 322     7225.5KB      6079.8KB     210.7KB     55
 350       62.8KB        61.9KB      61.9KB      0
 361       62.8KB        61.9KB      61.9KB      0
 367       62.8KB        61.6KB      61.6KB      0
 380       62.8KB        12.2KB      12.2KB      0
 413       62.8KB        61.9KB      61.9KB      0
 417       62.8KB        51.4KB      51.4KB      0
TEACH PENDANT:
Total -    0.0MB   Current -   0.0MB    Minimum -    0.0MB
 ***At Cold Start.***

ERRALL.LS      Robot Name ROBOT 21-AUG-26 12:02:48  

1" 21-AUG-26 12:02:48 " R E S E T                                         " "                               00000000"    "
2" 21-AUG-26 12:02:40 " SYST-026 System normal power up                   " " WARN                          00000000"    "
3" 21-AUG-26 12:02:38 " PWD -009 Delete program RLSTHSCD.TP               " " NONE                          10000000"    "
4" 21-AUG-26 12:02:38 " PWD -009 Delete program CPDEF.TP                  " " NONE                          10000000"    "
5" 21-AUG-26 12:02:38 " PWD -009 Delete program FTPSTART.TP               " " NONE                          10000000"    "
6" 21-AUG-26 12:02:38 " PWD -009 Delete program MOTNLIBDEF.TP             " " NONE                          10000000"    "
7" 21-AUG-26 12:02:38 " PWD -009 Delete program ITPSELDEF.TP              " " NONE                          10000000"    "
8" 21-AUG-26 12:02:38 " PWD -009 Delete program MOMCOREDEF.TP             " " NONE                          10000000"    "
9" 21-AUG-26 12:02:38 " PWD -009 Delete program OPTCNFDEF.TP              " " NONE                          10000000"    "
10" 21-AUG-26 12:02:28 " PWD -034 Login (Guest) SETUP    from Teach Pendant" " WARN                          00000000"    "
11" 21-AUG-26 12:02:26 " OPTN-017 No UPDATES on this media                 " " WARN                          00000000"    "
12" 21-AUG-26 12:02:26 " SYST-290 Cycle power to use new DCS parameter     " " STOP.G                        00100110"    "
13" 21-AUG-26 12:02:22 " PWD -025 Load MED:\00\TEMP\TRIAL.TP               " " NONE                          10000000"    "
14" 21-AUG-26 12:02:22 " TPIF-218 MED:\00\TEMP\SENDSYSV.TP failed to load  " MEMO-006 Protection error occurred                " WARN                          00000000"    "
15" 21-AUG-26 12:02:22 " TPIF-218 MED:\00\TEMP\SENDEVNT.TP failed to load  " MEMO-006 Protection error occurred                " WARN                          00000000"    "
16" 21-AUG-26 12:02:22 " TPIF-218 MED:\00\TEMP\SENDDATA.TP failed to load  " MEMO-006 Protection error occurred                " WARN                          00000000"    "
17" 21-AUG-26 12:02:22 " TPIF-218 MED:\00\TEMP\REQMENU.TP failed to load   " MEMO-006 Protection error occurred                " WARN                          00000000"    "
18" 21-AUG-26 12:02:22 " TPIF-218 MED:\00\TEMP\GETDATA.TP failed to load   " MEMO-006 Protection error occurred                " WARN                          00000000"    "
19" 21-AUG-26 12:02:22 " PWD -025 Load MED:\00\TEMP\-BCKEDT-.TP            " " NONE                          10000000"    "
20" 21-AUG-26 12:02:22 " PWD -025 Load MED:\00\TEMP\-BCKED9-.TP            " " NONE                          10000000"    "
21" 21-AUG-26 12:02:22 " PWD -025 Load MED:\00\TEMP\-BCKED8-.TP            " " NONE                          10000000"    "
22" 21-AUG-26 12:02:22 " PWD -026 Load MDS8:\VC_MOVE.VR as Program VC_MOVE " " NONE                          10000000"    "
23" 21-AUG-26 12:02:22 " PWD -026 Load MDS7:\TPSNAP.VR as Program TPSNAP   " " NONE                          10000000"    "
24" 21-AUG-26 12:02:22 " PWD -026 Load MDS6:\TBSWRC21.VR as Program TBSWRC21" " NONE                          10000000"    "
25" 21-AUG-26 12:02:22 " PWD -026 Load MDS4:\RUNPY.VR as Program RUNPY     " " NONE                          10000000"    "
26" 21-AUG-26 12:02:22 " PWD -026 Load MDS0:\MTPARAM.VR as Program MTPARAM " " NONE                          10000000"    "
27" 21-AUG-26 12:02:22 " PWD -026 Load MDS9:\IRC_STLABEL.VR as Program IRC_STLABEL" " NONE                          10000000"    "
28" 21-AUG-26 12:02:22 " PWD -026 Load MDS8:\IRC_STATUS.VR as Program IRC_STATUS" " NONE                          10000000"    "
29" 21-AUG-26 12:02:22 " PWD -026 Load MDS7:\IRC_MSG.VR as Program IRC_MSG " " NONE                          10000000"    "
30" 21-AUG-26 12:02:20 " PWD -026 Load MDS6:\IRC_COUNTER.VR as Program IRC_COUNTER" " NONE                          10000000"    "
31" 21-AUG-26 12:02:20 " PWD -026 Load MDS5:\HTTPKCL.VR as Program HTTPKCL " " NONE                          10000000"    "
32" 21-AUG-26 12:02:20 " PWD -026 Load MDS4:\GEMDATA.VR as Program GEMDATA " " NONE                          10000000"    "
33" 21-AUG-26 12:02:20 " PWD -026 Load MDS3:\FRAMEVAR.VR as Program TPFDEF " " NONE                          10000000"    "
34" 21-AUG-26 12:02:20 " PWD -026 Load MDS2:\COMSET.VR as Program COMSET   " " NONE                          10000000"    "
35" 21-AUG-26 12:02:20 " PWD -026 Load MDS0:\CBPARAM.VR as Program CBPARAM " " NONE                          10000000"    "
36" 21-AUG-26 12:02:20 " PWD -026 Load MDS9:\BICSETUP.VR as Program BICSETUP" " NONE                          10000000"    "
37" 21-AUG-26 12:02:20 " PWD -026 Load MDS8:\ABORTPY.VR as Program ABORTPY " " NONE                          10000000"    "
38" 21-AUG-26 12:02:20 " PWD -026 Load MDS7:\AAVMMAIN.VR as Program AAVMMAIN" " NONE                          10000000"    "
39" 21-AUG-26 12:02:20 " PWD -026 Load MDS6:\AAVMFREEPOS.VR as Program AAVMFREEPOS" " NONE                          10000000"    "
40" 21-AUG-26 12:02:18 " PWD -025 Load MDS6:\DIOCFGSV.IO                   " " NONE                          10000000"    "
41" 21-AUG-26 12:02:18 " PWD -026 Load MDS4:\FRAMEVAR.VR as Program TPFDEF " " NONE                          10000000"    "
42" 21-AUG-26 12:02:06 " VARS-005 $PGTRACEDT PC array length ignored       " VARS-023 Array len creation mismatch              " WARN                          00000000"    "
43" 21-AUG-26 12:02:06 " VARS-005 $PGTRACECTL PC array length ignored      " VARS-023 Array len creation mismatch              " WARN                          00000000"    "
44" 21-AUG-26 12:02:06 " VARS-005 $DB_RECORD PC array length ignored       " VARS-023 Array len creation mismatch              " WARN                          00000000"    "
45" 21-AUG-26 12:02:02 " VARS-005 $PGTRACEDT PC array length ignored       " VARS-023 Array len creation mismatch              " WARN                          00000000"    "
46" 21-AUG-26 12:02:02 " VARS-005 $PGTRACECTL PC array length ignored      " VARS-023 Array len creation mismatch              " WARN                          00000000"    "
47" 21-AUG-26 12:02:02 " VARS-005 $DB_RECORD PC array length ignored       " VARS-023 Array len creation mismatch              " WARN                          00000000"    "
48" 21-AUG-26 12:01:58 " OPTN-017 No UPDATES on this media                 " " WARN                          00000000"    "
49" 21-AUG-26 12:01:58 " PWD -008 Create program -REDO_BUFFER8.TP          " " NONE                          10000000"    "
50" 21-AUG-26 12:01:58 " PWD -008 Create program -UNDO_BUFFER8.TP          " " NONE                          10000000"    "
51" 21-AUG-26 12:01:58 " PWD -008 Create program -REDO_BUFFER7.TP          " " NONE                          10000000"    "
52" 21-AUG-26 12:01:58 " PWD -008 Create program -UNDO_BUFFER7.TP          " " NONE                          10000000"    "
53" 21-AUG-26 12:01:58 " PWD -008 Create program DF_LOGI6.TP               " " NONE                          10000000"    "
54" 21-AUG-26 12:01:58 " PWD -008 Create program DF_LOGI5.TP               " " NONE                          10000000"    "
55" 21-AUG-26 12:01:58 " PWD -008 Create program DF_LOGI4.TP               " " NONE                          10000000"    "
56" 21-AUG-26 12:01:58 " PWD -008 Create program DF_LOGI3.TP               " " NONE                          10000000"    "
57" 21-AUG-26 12:01:58 " PWD -008 Create program DF_LOGI2.TP               " " NONE                          10000000"    "
58" 21-AUG-26 12:01:58 " PWD -008 Create program DF_LOGI1.TP               " " NONE                          10000000"    "
59" 21-AUG-26 12:01:58 " PWD -026 Load MFS:\MTRC21.VR as Program MTPARAM   " " NONE                          10000000"    "
60" 21-AUG-26 12:01:58 " PWD -008 Create program -REDO_BUFFER0.TP          " " NONE                          10000000"    "
61" 21-AUG-26 12:01:58 " PWD -008 Create program -UNDO_BUFFER0.TP          " " NONE                          10000000"    "
62" 21-AUG-26 12:01:56 " OPTN-018 No Language additions on this media      " " WARN                          00000000"    "

 ***At Cold Start.***

F Number: F00000    
VERSION : HandlingTool         
$VERSION: V10.10307     1/22/2026
DATE:     21-AUG-26 12:02 

MEMORY USAGE::

MEMORY DETAIL (MAIN):
Pools        TOTAL     AVAILABLE      LARGEST
TPP             .9MB        .9MB        .9MB
PERM           3.0MB       1.3MB       1.3MB
SYSTEM          .0MB       0.0MB       0.0MB
SHADOW         6.5MB       5.5MB        .0MB
PAGE         207.7MB     124.9MB     124.9MB
TEMP          63.9MB      39.9MB      39.9MB
FR           252.0MB     196.2MB

HARDWARE
FROM     256MB
DRAM      27MB
NVRAM       3MB

MEMORY DETAIL (MAIN - TASKS):
TASK        TOTAL     AVAILABLE     LARGEST   REALLOC
   1      126.8KB        58.5KB      55.2KB      1
   2      126.8KB        51.9KB      47.3KB      1
   3       62.8KB         2.7KB       2.7KB      0
   4       62.8KB         2.7KB       2.7KB      0
   5      126.8KB        66.6KB      64.0KB      1
   6       62.8KB         2.7KB       2.7KB      0
   7       62.8KB         2.7KB       2.7KB      0
  33       62.8KB        61.4KB      61.4KB      0
  34       62.8KB        30.4KB      30.4KB      0
  35    11993.0KB       543.1KB      17.8KB     76
  36     1518.8KB      1244.3KB    1243.6KB      0
  37       62.8KB        61.9KB      61.9KB      0
  38     1998.8KB      1017.2KB    1017.2KB      0
  39     3366.5KB      3277.0KB     234.8KB     14
  40       62.8KB        61.6KB      61.6KB      0
  41      134.8KB        47.7KB      37.5KB      1
  42      190.8KB        89.7KB      31.0KB      2
  47       62.8KB        61.5KB      61.5KB      0
  51       62.8KB        60.7KB      60.7KB      0
  52     2982.2KB      1546.5KB     204.0KB     26
  71       62.8KB        61.4KB      61.0KB      0
  72       62.8KB        60.3KB      60.3KB      0
  73       62.8KB        61.9KB      61.9KB      0
  74       62.8KB        61.4KB      61.4KB      0
  75       62.8KB        61.2KB      61.2KB      0
  76      190.8KB        51.4KB      47.6KB      2
  77       62.8KB        61.2KB      61.2KB      0
  78      254.8KB       252.5KB     248.0KB      0
  97       62.8KB        57.7KB      57.7KB      0
  99       62.8KB        61.8KB      61.8KB      0
 100       62.8KB        58.9KB      58.9KB      0
 101       62.8KB        49.6KB      49.6KB      0
 102       94.8KB        93.6KB      93.6KB      0
 103       94.8KB        93.6KB      93.6KB      0
 104       94.8KB        93.6KB      93.6KB      0
 105       94.8KB        93.6KB      93.6KB      0
 106       94.8KB        93.6KB      93.6KB      0
 107       94.8KB        93.6KB      93.6KB      0
 108      298.8KB        33.7KB      24.8KB      3
 109      958.8KB       590.4KB     577.9KB      0
 114       62.8KB        61.0KB      61.0KB      0
 150       62.8KB        51.4KB      51.4KB      0
 153       62.8KB        61.0KB      61.0KB      0
 159     1406.7KB        18.0KB      16.0KB      6
 166       62.8KB        28.9KB      28.9KB      0
 170      190.8KB        93.2KB      26.8KB      2
 171       62.8KB        56.7KB      56.7KB      0
 174       62.8KB        61.0KB      61.0KB      0
 177       62.8KB        44.8KB      44.8KB      0
 182       62.8KB        35.4KB      35.4KB      0
 184       62.8KB        61.4KB      61.4KB      0
 186       62.8KB        50.7KB      50.7KB      0
 187      190.8KB        81.5KB      31.0KB      2
 188       62.8KB        62.8KB      62.8KB      0
 189       62.8KB        62.8KB      62.8KB      0
 190       62.8KB        62.8KB      62.8KB      0
 191       62.8KB        62.8KB      62.8KB      0
 192       62.8KB        61.9KB      61.9KB      0
 193       62.8KB        62.8KB      62.8KB      0
 199       62.8KB        62.8KB      62.8KB      0
 207       62.8KB        61.6KB      61.6KB      0
 209       62.8KB        61.8KB      61.8KB      0
 211       62.8KB        61.4KB      61.4KB      0
 214       62.8KB        61.6KB      61.6KB      0
 217       62.8KB         8.5KB       8.5KB      0
 221       62.8KB        50.5KB      50.5KB      0
 231       62.8KB        27.8KB      27.8KB      0
 232       62.8KB        61.4KB      61.4KB      0
 234       62.8KB        50.8KB      50.8KB      0
 239       62.8KB        60.5KB      60.5KB      0
 240       62.8KB        60.5KB      60.5KB      0
 256       62.8KB        62.6KB      62.4KB      0
 257       62.8KB        62.8KB      62.8KB      0
 258       62.8KB        62.8KB      62.8KB      0
 259       62.8KB        62.8KB      62.8KB      0
 260       62.8KB        62.8KB      62.8KB      0
 261       62.8KB        62.8KB      62.8KB      0
 262       62.8KB        62.8KB      62.8KB      0
 263       62.8KB        62.8KB      62.8KB      0
 264       62.8KB        62.8KB      62.8KB      0
 265       62.8KB        62.8KB      62.8KB      0
 297      142.8KB        64.2KB      60.3KB      1
 300       62.8KB        41.9KB      31.8KB      0
 301       62.8KB        61.9KB      61.9KB      0
 302      138.8KB         7.9KB       4.0KB      1
 317       62.8KB        61.9KB      61.9KB      0
 322     2302.4KB      2105.6KB    1007.4KB     20
 332       62.8KB        59.3KB      59.3KB      0
 337      846.6KB       275.0KB      67.7KB      8
 341       62.8KB        61.6KB      61.6KB      0
 350       62.8KB        61.9KB      61.9KB      0
 355       62.8KB        61.6KB      61.6KB      0
 356       62.8KB        61.5KB      61.5KB      0
 361       62.8KB        61.9KB      61.9KB      0
 367       62.8KB        61.6KB      61.6KB      0
 380       62.8KB        12.2KB      12.2KB      0
 413       62.8KB        61.9KB      61.9KB      0
 417       62.8KB        51.4KB      51.4KB      0
TEACH PENDANT:
Total -    0.0MB   Current -   0.0MB    Minimum -    0.0MB** Update Complete 21-AUG-26 12:02 

26/08/21 18:03:16

Version:  V10.10P/28/None
Build ID: V10.10307     1/22/2026

1A05B-2500-H552
1A05B-2500-H521
1A05B-2500-R796
1A05B-2500-R663
1A05B-2500-J556
1A05B-2500-J567
1A05B-2500-R651
1A05B-2500-R553
1A05B-2500-R641
1A05B-2500-J541
1A05B-2500-FVRC
1A05B-2500-H720
Z
