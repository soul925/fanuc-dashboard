ERREXT.LS      Robot Name ROBOT 21-AUG-26 18:08:50  

The Extended Alarm Log option must be loaded and enabled